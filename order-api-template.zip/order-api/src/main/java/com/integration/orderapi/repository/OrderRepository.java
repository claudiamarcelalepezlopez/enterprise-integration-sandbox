package com.integration.orderapi.repository;

import com.integration.orderapi.model.Order;
import com.integration.orderapi.model.Order.OrderStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;

/**
 * Spring Data JPA derives SQL from method names at startup —
 * no implementation code needed for standard queries.
 */
public interface OrderRepository extends JpaRepository<Order, Long> {

    Page<Order> findByCustomerId(String customerId, Pageable pageable);

    Page<Order> findByStatus(OrderStatus status, Pageable pageable);

    // JPQL — keeps query portable across DB vendors (H2 dev ↔ PostgreSQL prod)
    @Query("""
        SELECT o FROM Order o
        WHERE o.customerId = :customerId
          AND o.status     = :status
          AND o.createdAt >= :from
        ORDER BY o.createdAt DESC
        """)
    Page<Order> findByCustomerIdAndStatusSince(
        @Param("customerId") String customerId,
        @Param("status")     OrderStatus status,
        @Param("from")       Instant from,
        Pageable pageable
    );
}
