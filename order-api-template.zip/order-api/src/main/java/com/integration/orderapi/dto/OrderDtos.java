package com.integration.orderapi.dto;

import com.integration.orderapi.model.Order.OrderStatus;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.Instant;

/**
 * DTOs as Java 17 Records — immutable, concise, zero boilerplate.
 *
 * Separate records for Request vs Response:
 * - Prevents over-posting attacks (client can't set id, createdAt, etc.)
 * - Allows independent evolution of API surface vs DB schema
 */
public class OrderDtos {

    // ─── Inbound ────────────────────────────────────────────────────────────

    public record CreateOrderRequest(
        @NotBlank(message = "customerId is required")
        @Size(max = 100)
        String customerId,

        @NotNull(message = "amount is required")
        @Positive(message = "amount must be greater than zero")
        @Digits(integer = 10, fraction = 2)
        BigDecimal amount,

        @Size(max = 500)
        String description
    ) {}

    public record UpdateOrderStatusRequest(
        @NotNull(message = "status is required")
        OrderStatus status
    ) {}

    // ─── Outbound ───────────────────────────────────────────────────────────

    public record OrderResponse(
        Long id,
        String customerId,
        BigDecimal amount,
        OrderStatus status,
        String description,
        Instant createdAt,
        Instant updatedAt
    ) {}

    // ─── Pagination wrapper ─────────────────────────────────────────────────

    public record PagedResponse<T>(
        java.util.List<T> content,
        int pageNumber,
        int pageSize,
        long totalElements,
        int totalPages,
        boolean last
    ) {}
}
