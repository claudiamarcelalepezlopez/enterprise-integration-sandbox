package com.integration.orderapi.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

public class OrderExceptions {

    @ResponseStatus(HttpStatus.NOT_FOUND)
    public static class OrderNotFoundException extends RuntimeException {
        public OrderNotFoundException(Long id) {
            super("Order not found: id=" + id);
        }
    }

    @ResponseStatus(HttpStatus.CONFLICT)
    public static class InvalidStatusTransitionException extends RuntimeException {
        public InvalidStatusTransitionException(String from, String to) {
            super("Cannot transition order from [%s] to [%s]".formatted(from, to));
        }
    }
}
