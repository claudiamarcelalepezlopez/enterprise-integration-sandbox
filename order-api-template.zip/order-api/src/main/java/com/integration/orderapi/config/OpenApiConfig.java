package com.integration.orderapi.config;

import io.swagger.v3.oas.models.*;
import io.swagger.v3.oas.models.info.*;
import org.springframework.context.annotation.*;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI orderApiOpenAPI() {
        return new OpenAPI()
            .info(new Info()
                .title("Order Processing API")
                .description("REST API connecting the order processing system to the database")
                .version("1.0.0")
                .contact(new Contact()
                    .name("Integration Architecture Team")
                    .email("integration@example.com")));
    }
}
