package com.integration.orderapi.dto;

import com.integration.orderapi.model.Order;
import com.integration.orderapi.dto.OrderDtos.*;
import org.mapstruct.*;

/**
 * MapStruct generates the implementation at compile time — no reflection,
 * no runtime cost, and mismatched fields surface as compiler warnings.
 */
@Mapper(componentModel = "spring")
public interface OrderMapper {

    Order toEntity(CreateOrderRequest request);

    OrderResponse toResponse(Order order);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    void updateStatusFromRequest(UpdateOrderStatusRequest request, @MappingTarget Order order);
}
