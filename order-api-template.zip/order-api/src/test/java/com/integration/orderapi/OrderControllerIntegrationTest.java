package com.integration.orderapi;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.integration.orderapi.dto.OrderDtos.*;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.*;

import java.math.BigDecimal;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class OrderControllerIntegrationTest {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;

    private static Long createdOrderId;

    @Test
    @org.junit.jupiter.api.Order(1)
    void shouldCreateOrder() throws Exception {
        var request = new CreateOrderRequest("CUST-001", new BigDecimal("199.99"), "Test order");

        MvcResult result = mockMvc.perform(post("/api/v1/orders")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isCreated())
            .andExpect(header().exists("Location"))
            .andExpect(jsonPath("$.customerId").value("CUST-001"))
            .andExpect(jsonPath("$.status").value("PENDING"))
            .andReturn();

        String location = result.getResponse().getHeader("Location");
        assert location != null;
        createdOrderId = Long.parseLong(location.substring(location.lastIndexOf('/') + 1));
    }

    @Test
    @org.junit.jupiter.api.Order(2)
    void shouldGetOrderById() throws Exception {
        mockMvc.perform(get("/api/v1/orders/{id}", createdOrderId))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id").value(createdOrderId));
    }

    @Test
    @org.junit.jupiter.api.Order(3)
    void shouldUpdateOrderStatus() throws Exception {
        var request = new UpdateOrderStatusRequest(com.integration.orderapi.model.Order.OrderStatus.CONFIRMED);

        mockMvc.perform(patch("/api/v1/orders/{id}/status", createdOrderId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status").value("CONFIRMED"));
    }

    @Test
    @org.junit.jupiter.api.Order(4)
    void shouldRejectInvalidStatusTransition() throws Exception {
        // CONFIRMED → DELIVERED is not a valid transition
        var request = new UpdateOrderStatusRequest(com.integration.orderapi.model.Order.OrderStatus.DELIVERED);

        mockMvc.perform(patch("/api/v1/orders/{id}/status", createdOrderId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isConflict());
    }

    @Test
    void shouldReturn404ForUnknownOrder() throws Exception {
        mockMvc.perform(get("/api/v1/orders/99999"))
            .andExpect(status().isNotFound());
    }

    @Test
    void shouldReturn422ForInvalidRequest() throws Exception {
        var request = new CreateOrderRequest("", new BigDecimal("-10"), null);

        mockMvc.perform(post("/api/v1/orders")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isUnprocessableEntity())
            .andExpect(jsonPath("$.fieldErrors").exists());
    }
}
